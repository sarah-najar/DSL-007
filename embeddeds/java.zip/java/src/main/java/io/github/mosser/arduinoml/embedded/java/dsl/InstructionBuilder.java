package io.github.mosser.arduinoml.embedded.java.dsl;


import io.github.mosser.arduinoml.kernel.behavioral.Action;
import io.github.mosser.arduinoml.kernel.structural.Actuator;
import io.github.mosser.arduinoml.kernel.structural.SIGNAL;
import io.github.mosser.arduinoml.kernel.structural.Buzzer;
import io.github.mosser.arduinoml.kernel.structural.LCDScreen;

import java.util.Optional;

public class InstructionBuilder {

    private StateBuilder parent;

    private Action local =  new Action();

    InstructionBuilder(StateBuilder parent, String target) {
        this.parent = parent;
        Optional<Actuator> opt = parent.parent.findActuator(target);
        Actuator act = opt.orElseThrow(() -> new IllegalArgumentException("Illegal actuator: ["+target+"]"));
        local.setActuator(act);
    }

    public StateBuilder toHigh() { local.setValue(SIGNAL.HIGH); return goUp(); }

    public StateBuilder toLow() { local.setValue(SIGNAL.LOW); return goUp(); }

    public StateBuilder shortBeep() {
        if (!(local.getActuator() instanceof Buzzer))
            throw new IllegalArgumentException("shortBeep can only be used with a buzzer actuator");
        local.setBeep(Action.BEEP.SHORT);
        return goUp();
    }

    public StateBuilder longBeep() {
        if (!(local.getActuator() instanceof Buzzer))
            throw new IllegalArgumentException("longBeep can only be used with a buzzer actuator");
        local.setBeep(Action.BEEP.LONG);
        return goUp();
    }

    public StateBuilder display(String text) {
        if (!(local.getActuator() instanceof LCDScreen))
            throw new IllegalArgumentException("display can only be used with an LCD screen actuator");
        local.setLcdMessage(text);
        return goUp();
    }

    private StateBuilder goUp() {
        parent.local.getActions().add(this.local);
        return parent;
    }

}
