package io.github.mosser.arduinoml.embedded.java.dsl;


import io.github.mosser.arduinoml.kernel.behavioral.SignalTransition;
import io.github.mosser.arduinoml.kernel.behavioral.TimeTransition;
import io.github.mosser.arduinoml.kernel.behavioral.Transition;
import io.github.mosser.arduinoml.kernel.behavioral.State;
import io.github.mosser.arduinoml.kernel.structural.SIGNAL;
import io.github.mosser.arduinoml.kernel.structural.Sensor;

public class TransitionBuilder {

    private final TransitionTableBuilder parent;
    private final State sourceState;

    private enum MODE { NONE, SIGNAL, TIME }
    private MODE mode = MODE.NONE;

    private Sensor sensor;
    private SIGNAL sensorValue;
    private Integer delayMs;

    TransitionBuilder(TransitionTableBuilder parent, String source) {
        this.parent = parent;
        this.sourceState = parent.findState(source);
    }

    public TransitionBuilder when(String sensor) {
        this.mode = MODE.SIGNAL;
        this.sensor = parent.findSensor(sensor);
        return this;
    }

    public TransitionBuilder isHigh() {
        if (mode != MODE.SIGNAL) throw new IllegalStateException("isHigh() requires a preceding when(sensor)");
        this.sensorValue = SIGNAL.HIGH;
        return this;
    }

    public TransitionBuilder isLow() {
        if (mode != MODE.SIGNAL) throw new IllegalStateException("isLow() requires a preceding when(sensor)");
        this.sensorValue = SIGNAL.LOW;
        return this;
    }

    public TransitionBuilder after(int milliseconds) {
        if (milliseconds < 0) throw new IllegalArgumentException("Delay must be >= 0");
        this.mode = MODE.TIME;
        this.delayMs = milliseconds;
        return this;
    }

    public TransitionTableBuilder goTo(String state) {
        Transition t;
        switch (mode) {
            case SIGNAL:
                if (sensor == null || sensorValue == null)
                    throw new IllegalStateException("Incomplete signal transition (sensor/value)");
                SignalTransition st = new SignalTransition();
                st.setSensor(sensor);
                st.setValue(sensorValue);
                st.setNext(parent.findState(state));
                t = st;
                break;
            case TIME:
                if (delayMs == null)
                    throw new IllegalStateException("Incomplete time transition (delay)");
                TimeTransition tt = new TimeTransition();
                tt.setDelay(delayMs);
                tt.setNext(parent.findState(state));
                t = tt;
                break;
            default:
                throw new IllegalStateException("Transition must be configured (when(...) or after(...))");
        }
        sourceState.addTransition(t);
        return parent;
    }
}
